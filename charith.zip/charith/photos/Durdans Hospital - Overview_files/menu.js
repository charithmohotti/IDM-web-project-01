onerror = handle;

function handle(){
	 return true;
	}

var currentMenu = null;
var menuHideTimer = null;
var showTime = 100; // ms

function showMenu(str,obj){	
if (str!=currentMenu){
	//$E('.selectMenu').style.visibility = 'none';
	hideMenu();
	resetTimer();
	var off = 32;
	var pos = Array();
	pos = findPos(obj);
	obj2 = document.getElementById(str);
	obj2.style.display = "block";
	
	var inv = new Fx.Style(str, 'opacity').set(0); 
	var fx = new Fx.Styles(str,{duration:100,transition: Fx.Transitions.linear} ); 
	fx.start({
			 'opacity' : [100,0.9],
			 'padding-top' : [15,0]
			 });
	
	
	obj2.style.left = parseInt(pos[0]-0)+"px";
	obj2.style.top = parseInt(pos[1]+off)+"px";
	currentMenu = str;
	}
	else{
		resetTimer();
		}
}

function showIt(obj){
	//alert('s');
	obj.style.display = 'block';
	}
	
function hideMenu(){	

	if (currentMenu){
	obj = document.getElementById(currentMenu);
	obj.style.display = "none";
	currentMenu="";
	// do we want to be really fancy ??
	//if ($E('.selectMenu')){
	//$E('.selectMenu').style.display = 'block';
	//}
	//var inv = new Fx.Style(currentMenu, 'padding-top').set(0); 
	
}
	
	}	

function startTimer(){
	menuHideTimer = setTimeout("hideMenu()", showTime);
	}
	
function resetTimer(){
	if (menuHideTimer){
		clearTimeout(menuHideTimer);
	}
	menuHideTimer = null;	
	}
	

function findPos(obj) {  // http://www.quirksmode.org/js/findpos.html#
	var curleft = curtop = 0;
	if (obj.offsetParent) {
		curleft = obj.offsetLeft
		curtop = obj.offsetTop
		while (obj = obj.offsetParent) {
			curleft += obj.offsetLeft
			curtop += obj.offsetTop
		}
	}
	return [curleft,curtop];
}