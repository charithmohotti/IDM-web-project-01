<?php

session_start();
$user1=$_SESSION['username'];


?>

<!DOCTYPE html> 
<html>

<head>
  <title>Free HTML5 Templates</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
</head>

<body><?php
$username="root";
$password="";
$hostname="localhost";
$dbhandle=mysql_connect($hostname,$username,$password)
or die("Unable to connect to Mysql");

$selected=mysql_select_db("echannel",$dbhandle)
or die("could not select");

$result=mysql_query("select * from users where user_name='$user1'",$dbhandle);

while($row=mysql_fetch_array($result)){
$user=$row{'user_name'};
$name=$row{'name'};
$nic=$row{'nic'};
$email=$row{'email'};
	}
	
?>
  <div id="main">
	
    <header>
	  <div id="strapline">
	    <div id="welcome_slogan">
	      <a href="index.html"><img src="logo/durdans_logo.gif"></a>
	    </div><!--close welcome_slogan-->
      </div><!--close strapline-->	  
	  <nav>
	    <div id="menubar">
          <ul id="nav">
            <li><a href="index.html">Home</a></li>
            <li><a href="E-channel.html">E-channel</a></li>
            <li><a href="About.html">About</a></li>
            <li class="current"><a href="Members.php">Members</a></li>
            <li><a href="contact.html">Contact Us</a></li>
          </ul>
        </div><!--close menubar-->	
      </nav>
    </header>
	
    <div id="slideshow_container">  
	  <div class="slideshow">
	    <ul class="slideshow">
          <li class="show"><img width="940" height="250" src="images/home_1.jpg" alt="&quot;Durdans hospital&quot;" /></li>
          <li><img width="940" height="250" src="images/home_2.jpg" alt="&quot;Durdans hospital&quot;" /></li>
          <li class="show"><img width="940" height="250" src="images/home_3.jpg" alt="&quot;Durdans hospital&quot;" /></li>
          <li class="show"><img width="940" height="250" src="images/home_4.jpg" alt="&quot;Durdans hospital&quot;" /></li>
        </ul> 
	  </div><!--close slideshow-->  	
	</div><!--close slideshow_container-->  	
    
	<div id="site_content">

	  
	  <div id="content">
        <div class="content_item">
          <h1>My Details</h1>
          
          <table border='1' width='100%'>
<tr><td>user_name</td><td>name</td><td>nic</td><td>email</td></tr>
    <tr><td><?php echo "$user";  ?> <td> <?php echo "$name";?></td><td><?php echo "$nic"; ?> </td><td><?php echo "$email"; ?></td></tr></table>     
		  
<table width="940" border="0">
  <tr>
    <td><form action="pay.php" method="post">
Doctors<select name="Doctors">
            <option>-SELECT-</option>
            <option>Dr Charith Fonseka-	Eye Surgeon</option>
            <option>Dr (Mrs) Udeni Dissanayaka-	Eye Surgeon</option>
            <option>Dr Prakash Priyadarshan-	Cardiologists</option>
            <option>Mrs Harshani Meegaswatte-	Dieticians</option>
            <option>Dr Chandana Amarasinghe-	Physicians</option>
            </select><br/>
            <input name="pay online" type="submit" value="pay online" class="logout">

</form></td>
    <td><form action="pay.php" method="post">
    Doctors<select name="Doctors">
            <option>-SELECT-</option>
            <option>Dr Bhagya Mohotti-	Plastic Surgeons</option>
            <option>Dr (Mrs) Maheshi Wijeratne-	Neurosurgeons</option>
            <option>Prof Srinath Chandrasekera-	Urologists</option>
            <option>Dr Sarath Amarasekara-	Gynaecologists</option>
            <option>Dr M S Rubasingha-	ENT Surgeons</option>
            </select><br/>
            <input name="pay online" type="submit" value="pay online" class="logout">
            </form></td>
  </tr>
</table>




<form action="logout.php" method="post">
<input name="log out" type="submit" value="log out" class="logout">
</form>

<img class="pd-img" src="http://ir.ebaystatic.com/pictures/aw/pics/logos/logoPayPal_51x14.png" alt="PayPal" border="0">
|
<img src="http://ir.ebaystatic.com/pictures/aw/pics/logos/CC_icons.png" alt="Visa/MasterCard, Amex, Discover" title="Visa/MasterCard, Amex, Discover" class="pd-pp-cc-container"><br/>
<span class="pd-pp-cc-logo">Processed by PayPal</span>

          </div><!--close signup-->
          </div><!--close login-->
			
	    </div><!--close content_item-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
    <footer>
	  <a href="index.html">Home</a> | <a href="E-channel.html">E-channel</a> | <a href="About.html">About</a> | <a href="Members.php">Members</a> | <a href="contact.html">Contact</a><br/><br/>
	  website by charith mohotti
    </footer>
  </div><!--close main-->
  
  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  
</body>
</html>
