<?php
$username="root";
$password="";
$database="echannel";
$name=$_POST['your_name'];
$email=$_POST['your_email'];
$message=$_POST['your_message'];

mysql_connect('localhost',$username,$password);
@mysql_select_db($database)or die("Unable to select database");

$result=mysql_query("insert into contact values('$name','$email','$message')");

if ($result){
	echo"Message sent sucsefully";
		}
		else{
		echo"Message Failed".mysql_error();}
mysql_close();
?>