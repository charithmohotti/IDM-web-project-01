<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$username="root";
$password="";
$database="login";

$user_name=$_POST['user_name'];
$pass=$_POST['password'];

mysql_connect('localhost',$username,$password);

mysql_select_db('echannel')or die("Unable to select database");

$query="select * from users where user_name='$user_name' and password='$pass'";

$result=mysql_query($query);

$num=mysql_num_rows($result);

if 
($num==1)
{
	
	session_start();
	
	$_SESSION['username']=$user_name;
	
	header("location:profile.php");

}
else
{
	echo"Login Failed";}
	
mysql_close();
?>

</body>
</html>