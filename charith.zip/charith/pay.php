<?php 
session_start();
if(!isset($_SESSION['username'])){
	
	header("location:members.php");
	
	}

 ?>



<!DOCTYPE html> 
<html>

<head>
  <title>Free HTML5 Templates</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
</head>

<body>
  <div id="main">
	
    <header>
	  <div id="strapline">
	    <div id="welcome_slogan">
	      <a href="index.html"><img src="logo/durdans_logo.gif""></a>
	    </div><!--close welcome_slogan-->
      </div><!--close strapline-->	  
	  <nav>
	    <div id="menubar">
          <ul id="nav">
            <li><a href="index.html">Home</a></li>
            <li><a href="E-channel.html">E-channel</a></li>
            <li class="current"><a href="About.html">About</a></li>
            <li><a href="Members.php">Members</a></li>
            <li><a href="contact.html">Contact Us</a></li>
          </ul>
        </div><!--close menubar-->	
      </nav>
    </header>
	
    <div id="slideshow_container">  
	  <div class="slideshow">
	    <ul class="slideshow">
          <li class="show"><img width="940" height="250" src="images/home_1.jpg" alt="&quot;Durdans hospital&quot;" /></li>
          <li><img width="940" height="250" src="images/home_2.jpg" alt="&quot;Durdans hospital&quot;" /></li>
          <li class="show"><img width="940" height="250" src="images/home_3.jpg" alt="&quot;Durdans hospital&quot;" /></li>
          <li class="show"><img width="940" height="250" src="images/home_4.jpg" alt="&quot;Durdans hospital&quot;" /></li>
        </ul> 
	  </div><!--close slideshow-->  	
	</div><!--close slideshow_container-->  	
    
	<div id="site_content">

	  
	  <div id="content">
        <div class="content_item">
        
        <form action="profile.php" method="post">
        <input name="back" type="submit" value="Back" class="logout"></form>

<table width="940" border="0">
  <tr>
    <td><a href=""><img src="photos/logo_paypal Bank.png" align="center"></a></td>
    
  </tr>
  
</table>




          
			
			</div><!--close content_container--> 
	    </div><!--close content_item-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
    <footer>
	  <a href="index.html">Home</a> | <a href="E-channel.html">E-channel</a> | <a href="About.html">About</a> | <a href="Members.php">Members</a> | <a href="contact.html">Contact</a><br/><br/>
	  website by charith mohotti
    </footer>  
  </div><!--close main-->
  
  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  
</body>
</html>