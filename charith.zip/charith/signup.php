<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$username="root";
$password="";
$database="echannel";

$u_name=$_POST['user_name'];
$nn=$_POST['name'];
$id=$_POST['nic'];
$mail=$_POST['email'];
$pass=$_POST['password'];



mysql_connect('localhost',$username,$password);

mysql_select_db($database)or die("Unable to select database");

$query="insert into users values ('$u_name','$nn','$id','$mail','$pass')";

$result=mysql_query($query);



if 
($result)
{echo "<!DOCTYPE html> 
<html>

<head>
  <title>Free HTML5 Templates</title>
  <meta name='description' content='website description' />
  <meta name='keywords' content='website keywords, website keywords' />
  <meta http-equiv='content-type' content='text/html; charset=windows-1252' />
  <link rel='stylesheet' type='text/css' href='css/style.css' />
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type='text/javascript' src='js/modernizr-1.5.min.js'></script>
</head>

<body>
  <div id='main'>
	
    <header>
	  <div id='strapline'>
	    <div id='welcome_slogan'>
	      <a href='index.html'><img src='logo/durdans_logo.gif'></a>
	    </div><!--close welcome_slogan-->
      </div><!--close strapline-->	  
	  <nav>
	    <div id='menubar'>
          <ul id='nav'>
            <li><a href='index.html'>Home</a></li>
            <li><a href='E-channel.html'>E-channel</a></li>
            <li><a href='About.html'>About</a></li>
            <li class='current'><a href='Members.php'>Members</a></li>
            <li><a href='contact.html'>Contact Us</a></li>
          </ul>
        </div><!--close menubar-->	
      </nav>
    </header>
	
    <div id='slideshow_container'>  
	  <div class='slideshow'>
	    <ul class='slideshow'>
          <li class='show'><img width='940' height='250' src='images/home_1.jpg' alt='&quot;Durdans hospital&quot;' /></li>
          <li><img width='940' height='250' src='images/home_2.jpg' alt='&quot;Durdans hospital&quot;' /></li>
          <li class='show'><img width='940' height='250' src='images/home_3.jpg' alt='&quot;Durdans hospital&quot;' /></li>
          <li class='show'><img width='940' height='250' src='images/home_4.jpg' alt='&quot;Durdans hospital&quot;' /></li>
        </ul> 
	  </div><!--close slideshow-->  	
	</div><!--close slideshow_container-->  	
    
	<div id='site_content'>

	  <h1>Login</h1>
	  <div id='content'>
        <div class='content_item'>
        <h1>Registration sucessful. login now </h1>
          <table width='940' border='0'>
  <tr>
    <td>
    <form action='login.php' method='post'>
          User Name<input name='user_name' type='text'><br/>
         
          Password<input name='password' type='password'><br/>
          <input name='Login'  value='Login'type='submit' class='button_login'>
          
          </form>
    </td>
    <td>
    
          </div><!--close login-->
			
	    </div><!--close content_item-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
    
  </div><!--close main-->
  
  <!-- javascript at the bottom for fast page loading -->
  <script type='text/javascript' src='js/jquery.min.js'></script>
  <script type='text/javascript' src='js/image_slide.js'></script>
  
</body>
</html>
";
}
	
else
{
	echo"Registration Failed";}
	
mysql_close();
?>



</body>
</html>