<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$username="root";
$password="";
$database="echannel";

$u_name=$_POST['user_name'];
$nn=$_POST['name'];
$pass=$_POST['password'];
$mail=$_POST['email'];
$id=$_POST['nic'];



mysql_connect('localhost',$username,$password);

mysql_select_db($database)or die("Unable to select database");

$query="insert into signup values ('$u_name','$nn','$pass','$mail','$id')";

$result=mysql_query($query);



if 
($result)
{echo"Registration Sucssecful";}

else
{
	echo"Registration Failed";}
	
mysql_close();
?>



</body>
</html>